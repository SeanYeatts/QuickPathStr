from quickpathstr import Filepath

# MAIN ENTRYPOINT
def main():
    test = Filepath(fr"C:\Users\myself\Desktop\MyFile.txt")
    print(test)

# TOP LEVEL SCRIPT ENTRYPOINT
if __name__ == '__main__':
    main()
